<?php
include 'db.php'; // Database connection

$sql = "SELECT id, username, email, password FROM users"; // Fetch password hash
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['id']) . "</td>";
        echo "<td>" . htmlspecialchars($row['username']) . "</td>";
        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
        // Display masked version of the password
        echo "<td>" . str_repeat('*', strlen($row['password'])) . "</td>";
        echo "<td>";
        // Pass actual encrypted password to the edit modal
        echo "<a href='#' class='button edit-button' onclick=\"openEditModal('{$row['id']}', '{$row['username']}', '{$row['email']}', '{$row['password']}')\">
        <i class='fas fa-edit'></i>
      </a> ";
echo "<a href='#' class='button delete-button' onclick=\"openDeleteModal('{$row['id']}')\">
        <i class='fas fa-trash-alt'></i>
      </a>";


        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='5'>No accounts found</td></tr>";
}

$conn->close();
?>
