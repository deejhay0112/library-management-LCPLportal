<?php
include 'db.php';

// Set the correct response type to JSON
header('Content-Type: application/json');

// Prepare response array
$response = [];

// Check if form values are set
if (isset($_POST['borrowedBook'], $_POST['borrowerName'], $_POST['borrowDate'], $_POST['returnDate'])) {
    
    // Get the values from the form
    $Book_name = $_POST['borrowedBook'];
    $borrower_Name = $_POST['borrowerName'];
    $borrow_Date = $_POST['borrowDate'];
    $return_Date = $_POST['returnDate'];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO borrowed_books (book_name, borrower_Name, borrow_Date, return_Date) VALUES (?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("ssss", $Book_name, $borrower_Name, $borrow_Date, $return_Date);

        // Execute the statement
        if ($stmt->execute()) {
            // Return success response
            $response['success'] = true;
            $response['message'] = "New record created successfully!";
        } else {
            // Return error response
            $response['success'] = false;
            $response['message'] = "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        // Return error response if statement preparation failed
        $response['success'] = false;
        $response['message'] = "Error preparing statement: " . $conn->error;
    }

    // Close the connection
    $conn->close();

} else {
    // Return error if required fields are missing
    $response['success'] = false;
    $response['message'] = "All form fields are required.";
}

// Return the response in JSON format
echo json_encode($response);
?>
