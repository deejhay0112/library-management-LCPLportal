<?php
include 'db.php'; // Ensure this includes your database connection setup

// Set the correct timezone
date_default_timezone_set('Asia/Manila'); // Adjust timezone if necessary

header('Content-Type: application/json'); // Set the response to JSON

$response = array(); // Prepare an array for the response

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Capture POST data
    $school = isset($_POST['school']) ? $_POST['school'] : null;
    $date = isset($_POST['date']) ? $_POST['date'] : null;
    $age = isset($_POST['age']) ? $_POST['age'] : null;
    $sex = isset($_POST['sex']) ? $_POST['sex'] : null;

    // Get the current time
    $time = date('H:i:s'); // Corrected timezone will be applied here

    // Educational levels (corrected)
    $elementary = isset($_POST['elementary']) && $_POST['elementary'] === 'yes' ? 'Yes' : 'No';
    $highschool = isset($_POST['highschool']) && $_POST['highschool'] === 'yes' ? 'Yes' : 'No';
    $college = isset($_POST['college']) && $_POST['college'] === 'yes' ? 'Yes' : 'No';
    $postgrad = isset($_POST['postgrad']) && $_POST['postgrad'] === 'yes' ? 'Yes' : 'No';
    $shs = isset($_POST['seniorhighschool']) && $_POST['seniorhighschool'] === 'yes' ? 'Yes' : 'No';
    $osy = isset($_POST['osy']) && $_POST['osy'] === 'yes' ? 'Yes' : 'No';

    // Fetch the highest ID from the male_1 table
    $highest_id = 1;
    $sql = "SELECT MAX(`ID No.`) AS max_id FROM male_1";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $highest_id = $row['max_id'] + 1;
    }

    // Insert data into the male_1 table
    $sql = "INSERT INTO male_1 (`ID No.`, school, date, age, sex, time, Elementry, Highschool, Shs, College, `PostGrad`, `Osy`)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("isssssssssss", $highest_id, $school, $date, $age, $sex, $time, $elementary, $highschool, $shs, $college, $postgrad, $osy);
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = "Logbook entry added successfully!";
        } else {
            $response['success'] = false;
            $response['message'] = "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $response['success'] = false;
        $response['message'] = "Error preparing the SQL statement.";
    }
    $conn->close();
} else {
    $response['success'] = false;
    $response['message'] = "No data received.";
}

// Return JSON response
echo json_encode($response);
