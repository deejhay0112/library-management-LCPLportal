<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: admin-login.php");
    exit();
}

// Prevent caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Expires: 0");
header("Pragma: no-cache");

$currentPage = 'dashboard';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
</head>
<body id="body-pd">
<header class="header" id="header">
    <div class="header__toggle">
        <i class='bx bx-menu' id="header-toggle"></i>
    </div>
    <!-- Adding a date picker to the header -->
    <div class="header__date-picker">
        <input type="date" id="header-date-picker" name="header-date-picker">
    </div>
</header>

    <div class="l-navbar" id="nav-bar">
        <nav class="nav">
            <div>
                <a href="#" class="nav__logo">
                    <img src="logo/vls_logo.jpg" alt="Library Logo" class="nav__logo-img">
                    <span class="nav__logo-name">LIPA CITY PUBLIC LIBRARY</span>
                </a>
                <div class="nav__list">
                    <a href="books.php" class="nav__link <?php echo ($currentPage == 'library_management') ? 'active' : ''; ?>">
                        <i class='bx bx-grid-alt nav__icon'></i>
                        <span class="nav__name">Library Management</span>
                    </a>

                    <a href="logbookAdmin.php" class="nav__link <?php echo ($currentPage == 'logbook') ? 'active' : ''; ?>">
                        <i class='bx bx-message-square-detail nav__icon'></i>
                        <span class="nav__name">Logbook</span>
                    </a>

                    <a href="dashboard.php
                    " class="nav__link <?php echo ($currentPage == 'dashboard') ? 'active' : ''; ?>">
                        <i class='bx bx-bar-chart-alt-2 nav__icon'></i>
                        <span class="nav__name">Analytics</span>
                    </a>

                    <a href="transaction_book.php" class="nav__link <?php echo ($currentPage == 'transaction_books') ? 'active' : ''; ?>">
                        <i class='bx bx-book nav__icon'></i>
                        <span class="nav__name">Transaction Books</span>
                    </a>
                    <a href="admin_account.php" class="nav__link <?php echo ($currentPage == 'admin_account') ? 'active' : ''; ?>">
                    <i class='bx bx-user nav__icon'></i>
                        <span class="nav__name">Admin</span>
                    </a>
                </div>
            </div>

            <a href="logout.php" class="nav__link">
                <i class='bx bx-log-out nav__icon'></i>
                <span class="nav__name">Log Out</span>
            </a>
            
    </div>

    <main>
        <div class="charts-container">
            <div class="dashboard-container">
                <!-- Total Visitors Card -->
                <div class="c-dashboardInfo col-lg-3 col-md-6">
                    <div class="wrap">
                        <h4 class="heading heading5 hind-font medium-font-weight c-dashboardInfo__title visitor-title">Total Visitors</h4>
                        <span class="hind-font caption-12 c-dashboardInfo__count" id="visitor-count">Loading...</span>
                        <div class="date-selection">
                            <input type="date" id="search-date" name="current-date" required>

                            </button>
                        </div>
                    </div>
                </div>

                <!-- Total Borrowed Books Card -->
                <div class="c-dashboardInfo col-lg-3 col-md-6">
                    <div class="wrap">
                        <h4 class="heading heading5 hind-font medium-font-weight c-dashboardInfo__title borrowed-title">Borrowed Books</h4>
                        <span class="hind-font caption-12 c-dashboardInfo__count" id="borrowed-count">Loading...</span>
                        <div class="date-selection">
                            <input type="date" id="borrow-date" name="borrow-date" required>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Gender Distribution Chart Section -->
            <div class="gender-chart-section chart-section">
                <div class="form-group input-group">
                    <input type="date" id="chart-date" name="chart-date" required>
                    <button class="button" id="fetch-chart-data">
                        <i class='bx bx-search'></i>
                    </button>
                </div>
                <div class="chart-container">
                    <div id="genderLoader" class="chart-loader"></div>
                    <canvas id="genderChart"></canvas>
                </div>
            </div>

            <!-- Education Chart Section -->
            <div class="education-chart-section chart-section">
                <div class="form-group input-group">
                    <input type="date" id="datePicker">
                    <button class='button' id="fetchData">
                        <i class='bx bx-search'></i>
                    </button>
                </div>
                <div class="chart-container">
                    <div id="educationLoader" class="chart-loader"></div>
                    <canvas id="donutChart"></canvas>
                </div>
            </div>
        </div>


        <div class="combined-container">
        
            <!-- Flex container for side-by-side layout -->
            <div class="side-by-side-charts">
                <!-- Visitor Count by Year -->
                <div class="visitor-chart-section chart-section">
                    <div class="form-group input-group">
                        <label for="chart-year">Select Year</label>
                        <select id="chart-year" name="chart-year" required>
                            <option value="">Select Year</option>
                            <!-- Year options will be populated dynamically -->
                        </select>
                        <button class="button" id="fetch-visitor-data">
                            <i class='bx bx-search'></i>
                        </button>
                    </div>
                    <div class="chart-container">
                        <canvas id="visitorChart"></canvas> <!-- Unique ID for visitor chart -->
                    </div>
                </div>
        
                <!-- Predicted Visitor Count (Monthly) -->
                <div class="month-visitor-chart-section chart-section">
                    <h3>Predicted Visitor Count (Monthly)</h3>
                    <div class="chart-container">
                        <canvas id="monthlypredVisitorChart"></canvas> <!-- Unique ID for monthly prediction chart -->
                    </div>
                </div>
            </div>
        </div>
<div class="forecast-wrapper">
    <div class="forecast-container">
        <button id="prev-button" onclick="navigateForecast(-7)">← Previous</button>
        
        <div id="forecast-cards" class="card-wrapper">
            <!-- Forecast cards will be dynamically populated here -->
        </div>
        
        <button id="next-button" onclick="navigateForecast(7)">Next →</button>
    </div>
</div>

        

  <!-- Forecasted Visitor Count (Larger Canvas) -->
  <div class="pred-visitor-chart-section chart-section">
    <h3>Forecasted Visitor Count</h3>
    <div class="pred-chart-container">
        <canvas id="forecastVisitorChart"></canvas> <!-- No inline width/height -->
    </div>
</div>


</main>
    



    <!-- Chart.js CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- JavaScript to handle chart and data -->
    <script src="assets/js/main.js"></script>
    <script src="assets/js/visitor_fetch.js"></script>
    <script src="assets/js/fetch_date.js"></script>
    <script src="assets/js/visitor_chart.js"></script>
    <script src="assets/js/visitor_chart_date.js"></script>
    <script src="assets/js/gender_chart.js"></script>
    <script src="assets/js/borrowbook_date.js"></script>
    <script src="assets/js/donut_chart.js"></script>
    <script src="assets/js/dashboard_date_picker.js"></script>
    <script src="assets/js/predictive_chart.js"></script>
    <script src="assets/js/predictive_monthly_chart.js"></script>
    
<script>
    let forecastData = [];
let currentStartIndex = 0;

// Fetch data from the Flask API
function fetchForecastData() {
    fetch('http://127.0.0.1:5000/visitor_forecast')
        .then(response => response.json())
        .then(data => {
            forecastData = data;
            displayForecastCards();
        })
        .catch(error => console.error('Error fetching forecast data:', error));
}

// Display 7-day forecast on cards
function displayForecastCards() {
    const cardWrapper = document.getElementById('forecast-cards');
    cardWrapper.innerHTML = '';  // Clear existing cards

    for (let i = currentStartIndex; i < currentStartIndex + 7; i++) {
        if (i >= forecastData.labels.length) break;

        // Create a card for each day in the forecast range
        const card = document.createElement('div');
        card.classList.add('card');

        const title = document.createElement('h5');
        title.classList.add('card-title');
        title.textContent = forecastData.labels[i];  // Display date

        const text = document.createElement('p');
        text.classList.add('card-text');
        text.textContent = forecastData.visitor_count[i];  // Display predicted visitor count

        card.appendChild(title);
        card.appendChild(text);
        cardWrapper.appendChild(card);
    }

    // Update navigation buttons' disabled state
    document.getElementById('prev-button').disabled = (currentStartIndex === 0);
    document.getElementById('next-button').disabled = (currentStartIndex + 7 >= forecastData.labels.length);
}

// Navigate forecast by shifting the index
function navigateForecast(offset) {
    currentStartIndex += offset;
    displayForecastCards();
}

// Fetch and display forecast on page load
fetchForecastData();

</script>

</body>
</html>
