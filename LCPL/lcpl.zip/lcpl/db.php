<?php
// db.php
$servername = "localhost";
$username = "root";  // Change if using another username
$password = "";      // Add your database password
$dbname = "lms"; // Change this to your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
