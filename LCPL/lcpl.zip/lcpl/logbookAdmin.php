<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: admin-login.php");
    exit();
}

// Prevent caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Expires: 0");
header("Pragma: no-cache");
?>
<?php
$currentPage = 'logbook';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logbook</title>
    <link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/logbookadmin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<body id="body-pd">
    <header class="header" id="header">
        <div class="header__toggle">
            <i class='bx bx-menu' id="header-toggle"></i>
        </div>
    </header>

    <div class="l-navbar" id="nav-bar">
        <nav class="nav">
            <div>
                <a href="#" class="nav__logo">
                    <img src="logo/vls_logo.jpg" alt="Library Logo" class="nav__logo-img">
                    <span class="nav__logo-name">LIPA CITY PUBLIC LIBRARY</span>
                </a>
                <div class="nav__list">
                    <a href="books.php" class="nav__link <?php echo ($currentPage == 'library_management') ? 'active' : ''; ?>">
                        <i class='bx bx-grid-alt nav__icon'></i>
                        <span class="nav__name">Library Management</span>
                    </a>

                    <a href="logbookAdmin.php" class="nav__link <?php echo ($currentPage == 'logbook') ? 'active' : ''; ?>">
                        <i class='bx bx-message-square-detail nav__icon'></i>
                        <span class="nav__name">Logbook</span>
                    </a>

                    <a href="dashboard.php" class="nav__link <?php echo ($currentPage == 'dashboard') ? 'active' : ''; ?>">
                        <i class='bx bx-bar-chart-alt-2 nav__icon'></i>
                        <span class="nav__name">Analytics</span>
                    </a>

                    <a href="transaction_book.php" class="nav__link <?php echo ($currentPage == 'transaction_books') ? 'active' : ''; ?>">
                        <i class='bx bx-book nav__icon'></i>
                        <span class="nav__name">Transaction Books</span>
                    </a>
                    <a href="admin_account.php" class="nav__link <?php echo ($currentPage == 'admin_account') ? 'active' : ''; ?>">
                    <i class='bx bx-user nav__icon'></i>
                        <span class="nav__name">Admin</span>
                    </a>
                </div>
            </div>
            <a href="logout.php" class="nav__link">
                <i class='bx bx-log-out nav__icon'></i>
                <span class="nav__name">Log Out</span>
            </a>
        </nav>
    </div>
    
    <!-- Filter Container at the Top -->
    <main>
        <div class="table-container">
            <div class="filter-scroll-wrapper">
                <div class="filter-container-wrapper">
                    <form method="get" action="logbookAdmin.php">
                        <label for="startDate">Filter by Date:</label>
                        <input type="date" id="startDate" name="date">
                    </form>
                    <!-- Print Button -->
                    <button onclick="printLogbookRecords()" style="margin-top: 10px; padding: 8px 16px; background-color: #007bff; color: white; border: none; cursor: pointer;">Print Records</button>
                </div>
            </div>
        
            <div class="table-wrapper">
                <table id="logbookTable" class="display">
                    <thead>
                        <tr>
                            <th>Id No</th>
                            <th>School</th>
                            <th>Date</th>
                            <th>Age</th>
                            <th>Sex</th>
                            <th>Time</th>
                            <th>Elementary</th>
                            <th>JHS</th>
                            <th>SHS</th>
                            <th>College</th>
                            <th>Post Grad</th>
                            <th>OSY</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Data will be loaded here by JavaScript -->
                    </tbody>
                </table>
            </div>
    </main>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>
    <script>
     $(document).ready(function() {
    var table = $('#logbookTable').DataTable({
        "pageLength": 25,
        "lengthMenu": [10, 25, 50, 100],
        "pagingType": "full_numbers",
        "scrollX": true,
        "columns": [
            { "data": "ID_No" },
            { "data": "School" },
            { "data": "Date" },
            { "data": "Age" },
            { "data": "Sex" },
            { "data": "Time" },
            { "data": "Elementary" },
            { "data": "Highschool" },
            { "data": "Shs" },
            { "data": "College" },
            { "data": "PostGrad" },
            { "data": "Osy" }
        ],
        "dom": 'Bfrtip',
        "buttons": [
            {
                extend: 'csv',
                filename: function() {
                    const selectedDate = $('#startDate').val() || new Date().toISOString().split('T')[0];
                    return `logbook_record_${selectedDate}`;
                }
            },
            {
                extend: 'excel',
                filename: function() {
                    const selectedDate = $('#startDate').val() || new Date().toISOString().split('T')[0];
                    return `logbook_record_${selectedDate}`;
                }
            },
            {
                extend: 'pdf',
                filename: function() {
                    const selectedDate = $('#startDate').val() || new Date().toISOString().split('T')[0];
                    return `logbook_record_${selectedDate}`;
                }
            },
            {
                extend: 'print',
                title: function() {
                    const selectedDate = $('#startDate').val() || new Date().toISOString().split('T')[0];
                    return `Logbook Records - ${selectedDate}`;
                }
            }
        ],
        "initComplete": function () {
            // Add a custom search input for "School" column only
            $("#logbookTable_filter").html(`
                <label>Search School: 
                    <input type="text" id="schoolSearch" placeholder="Type school name">
                </label>
            `);
            
            // Apply search on the School column (column index 1)
            $('#schoolSearch').on('keyup change', function () {
                table.column(1).search(this.value).draw();
            });
        }
    });

    function fetchLogbookData(date) {
        $.ajax({
            url: 'fetch_logbook_ajax.php',
            type: 'GET',
            data: { date: date },
            success: function(data) {
                console.log("Data fetched:", data);
                table.clear().rows.add(data).draw();
            },
            error: function() {
                alert('Error loading data.');
            }
        });
    }

    const today = new Date().toISOString().split('T')[0];
    $('#startDate').val(today);
    fetchLogbookData(today);

    $('#startDate').on('change', function() {
        const selectedDate = $(this).val();
        fetchLogbookData(selectedDate);
    });
});

    </script>

    <script src="assets/js/main.js"></script>
</body>
</html>
