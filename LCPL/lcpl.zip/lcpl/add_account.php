<?php
include 'db.php'; // Ensure this file includes the database connection

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $conn->real_escape_string(trim($_POST['username']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $password = trim($_POST['password']);
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $checkQuery = "SELECT * FROM users WHERE email = '$email' OR username = '$username'";
    $checkResult = $conn->query($checkQuery);

    if ($checkResult->num_rows > 0) {
        header("Location: admin_account.php?status=exists");
    } else {
        $sql = "INSERT INTO users (username, email, password, created_at) VALUES ('$username', '$email', '$hashed_password', NOW())";

        if ($conn->query($sql) === TRUE) {
            header("Location: admin_account.php?status=added");
        } else {
            header("Location: admin_account.php?status=error");
        }
    }

    $conn->close();
}
