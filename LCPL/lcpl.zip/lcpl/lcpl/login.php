<?php
session_start();
include 'db.php';

// Set response type to JSON
header('Content-Type: application/json');

// Check if the request is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Retrieve the hashed password for the given username
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $storedHashedPassword = $row['password']; // Store the hashed password from the database

        // Verify the entered password against the stored hashed password
        if (password_verify($password, $storedHashedPassword)) {
            $_SESSION['username'] = $username;

            // Send success response with redirect URL
            echo json_encode(['success' => true, 'redirect' => 'books.php']);
            exit();
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid username or password.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid username or password.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}

$conn->close();
?>
