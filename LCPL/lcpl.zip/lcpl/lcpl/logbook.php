<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logbook</title>
    <link rel="stylesheet" href="assets/css/logbook.css">
    <!-- SweetAlert2 CDN -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <!-- Full-screen SVG for Background Curve -->
    <svg class="divider" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
        <path fill="#f5f5f5" fill-opacity="1" d="M0,240 C480,320 960,80 1440,160 L1440,320 L0,320 Z"></path>
    </svg>

    <!-- Main Content Area -->
    <main>
        <div class="box-container">
            <div class="form-container">
                <!-- Header Section -->
                <div class="header-container">
                    <img src="logo/vls_logo.jpg" alt="Library Logo" class="logo-image">
                    <h2>LIPA CITY PUBLIC LIBRARY LOGBOOK</h2>
                </div>

                <!-- Logbook Form -->
                <form id="logbookForm" action="insert_logbook.php" method="POST">
                    <div class="button-wrapper">
                        <button type="button" class="button borrow-book-button" onclick="openModal()">Borrow Book</button>
                    </div>
                    <input type="text" name="name" placeholder="Name" required>
                    <input type="number" name="age" placeholder="Age" required>
                    <input type="text" name="school" placeholder="School" required>

                    <!-- Educational Levels (Radio Buttons) -->
                    <div class="radio-group">
                        <label>Elementary:</label>
                        <label><input type="radio" name="elementary" value="yes"> Yes</label>
                    </div>
                    <div class="radio-group">
                        <label>Junior High School:</label>
                        <label><input type="radio" name="highschool" value="yes"> Yes</label>
                    </div>
                    <div class="radio-group">
                        <label>Senior High School:</label>
                        <label><input type="radio" name="seniorhighschool" value="yes"> Yes</label>
                    </div>
                    <div class="radio-group">
                        <label>College:</label>
                        <label><input type="radio" name="college" value="yes"> Yes</label>
                    </div>
                    <div class="radio-group">
                        <label>Post Graduate:</label>
                        <label><input type="radio" name="postgrad" value="yes"> Yes</label>
                    </div>
                    <div class="radio-group">
                        <label>Out of school:</label>
                        <label><input type="radio" name="osy" value="yes"> Yes</label>
                    </div>

                    <!-- Gender and Date/Time Inputs -->
                    <select name="sex" required>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="LGBTQ">LGBTQ</option>
                    </select>
                    <input type="text" id="dateInput" name="date" class="readonly-input" readonly>
                    <input type="text" id="timeInput" name="time" class="readonly-input" readonly>

                    <!-- Submit Button -->
                    <button type="submit" class="button borrow-book-button">Submit</button>
                </form>
            </div>
        </div>
    </main>

    <!-- Borrow Book Modal (Outside Main Content) -->
    <div id="borrowModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Borrow Book</h2>
                <span class="close" onclick="closeModal()">&times;</span>
            </div>
            <div class="modal-body">
                <form id="borrowBookForm" action="borrow_book_submit.php" method="POST">
                    <input type="hidden" id="bookId" name="bookId">
                    <div class="form-group">
                        <label for="borrowedBook">Book Name:</label>
                        <input type="text" id="borrowedBook" name="borrowedBook" placeholder="Search by title, author, or accession number" onkeyup="searchBooks()" required>
                        <div id="searchResults" class="search-results"></div>
                    </div>
                    <div class="form-group">
                        <label for="borrowerName">Borrower's Name:</label>
                        <input type="text" id="borrowerName" name="borrowerName" placeholder="Enter your name" required>
                    </div>
                    <div class="form-group">
                        <label for="borrowDate">Borrow Date:</label>
                        <input type="date" id="borrowDate" name="borrowDate" required>
                    </div>
                    <div class="form-group">
                        <label for="returnDate">Return Date:</label>
                        <input type="date" id="returnDate" name="returnDate" required>
                    </div>
                    <button type="submit">Submit</button>
                    <button type="button" onclick="closeModal()">Cancel</button>
                </form>
            </div>
        </div>
    </div>

    <!-- JavaScript Section -->
    <script src="assets/js/openModal.js"></script>
    <script src="assets/js/checkboxHandler.js"></script>
    <script src="assets/js/searchBooks.js"></script>
    <script src="assets/js/educationLevelHandler.js"></script>

    <script>
        // Logbook Form Submission with AJAX
        document.getElementById('logbookForm').addEventListener('submit', function(event) {
            event.preventDefault();
            const formData = new FormData(this);
            fetch('insert_logbook.php', { method: 'POST', body: formData })
            .then(response => response.json())
            .then(data => {
                Swal.fire({
                    title: data.success ? 'Success!' : 'Error!',
                    text: data.message,
                    icon: data.success ? 'success' : 'error',
                    confirmButtonText: 'OK'
                }).then(() => {
                    if (data.success) window.location.href = 'logbook.php';
                });
            }).catch(error => {
                console.error('Error:', error);
                Swal.fire('Error!', 'An unexpected error occurred. Please try again.', 'error');
            });
        });

        // Borrow Book Form Submission with AJAX
        document.getElementById('borrowBookForm').addEventListener('submit', function(event) {
            event.preventDefault();
            const formData = new FormData(this);
            fetch('borrow_book_submit.php', { method: 'POST', body: formData })
            .then(response => response.json())
            .then(data => {
                Swal.fire({
                    title: data.success ? 'Success!' : 'Error!',
                    text: data.message,
                    icon: data.success ? 'success' : 'error',
                    confirmButtonText: 'OK'
                }).then(() => {
                    if (data.success) window.location.href = 'logbook.php';
                });
            }).catch(error => {
                console.error('Error:', error);
                Swal.fire('Error!', 'An unexpected error occurred. Please try again.', 'error');
            });
        });

        // Functions to Open and Close Modal
        function openModal() {
            document.getElementById('borrowModal').style.display = 'flex';
        }
        
        function closeModal() {
            document.getElementById('borrowModal').style.display = 'none';
        }
    </script>
</body>
</html>
