
<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: admin-login.php");
    exit();
}

// Prevent caching for this page
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Expires: 0");
header("Pragma: no-cache");
?>
<?php
// Include your database connection file
require 'db.php'; // Adjust this path to your actual db.php file

// Define current page for active class logic
$currentPage = 'transaction_books'; // Set the current page name as needed

// Fetch borrowed books from the database
$sql = "SELECT id, book_name, borrower_name, borrow_date, return_date FROM borrowed_books";
$result = $conn->query($sql);

// Start HTML output
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="style.css"> <!-- Optional CSS -->
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/borrowbook.css">

</head>
<body>

<title>Sidebar menu responsive</title>
</head>
<body id="body-pd">
    <header class="header" id="header">
        <div class="header__toggle">
            <i class='bx bx-menu' id="header-toggle"></i>
        </div>
    </header>

    <div class="l-navbar" id="nav-bar">
        <nav class="nav">
            <div>
                <a href="#" class="nav__logo">
                    <img src="logo/vls_logo.jpg" alt="Library Logo" class="nav__logo-img">
                    <span class="nav__logo-name">LIPA CITY PUBLIC LIBRARY</span>
                </a>
                <div class="nav__list">
                    <a href="books.php" class="nav__link <?php echo ($currentPage == 'library_management') ? 'active' : ''; ?>">
                        <i class='bx bx-grid-alt nav__icon'></i>
                        <span class="nav__name">Library Management</span>
                    </a>

                    <a href="logbookAdmin.php" class="nav__link <?php echo ($currentPage == 'logbook') ? 'active' : ''; ?>">
                        <i class='bx bx-message-square-detail nav__icon'></i>
                        <span class="nav__name">Logbook</span>
                    </a>

                    <a href="dashboard.php" class="nav__link <?php echo ($currentPage == 'dashboard') ? 'active' : ''; ?>">
                        <i class='bx bx-bar-chart-alt-2 nav__icon'></i>
                        <span class="nav__name">Analytics</span>
                    </a>

                    <a href="transaction_book.php" class="nav__link <?php echo ($currentPage == 'transaction_books') ? 'active' : ''; ?>">
                        <i class='bx bx-book nav__icon'></i>
                        <span class="nav__name">Transaction Books</span>
                    </a>
                    <a href="admin_account.php" class="nav__link <?php echo ($currentPage == 'admin_account') ? 'active' : ''; ?>">
                    <i class='bx bx-user nav__icon'></i>
                        <span class="nav__name">Admin</span>
                    </a>
                </div>
            </div>

            <a href="logout.php" class="nav__link">
                <i class='bx bx-log-out nav__icon'></i>
                <span class="nav__name">Log Out</span>
            </a>
        </nav>
    </div>

<!-- Main Content -->
<div class="main-content">
    <div class="filter-section">
    <label for="dateFilter">Filter by:</label>
    <select id="dateFilter">
        <option value="borrow_date">Borrow Date</option>
        <option value="return_date">Return Date</option>
    </select>

    <label for="startDate">Start Date:</label>
    <input type="date" id="startDate">

    <label for="endDate">End Date:</label>
    <input type="date" id="endDate">

    <button id="filterBtn">Apply Filter</button>
</div>


</div>

<div class="table-wrapper"> <!-- Added class for the table wrapper to control scroll -->
    <?php
    if ($result->num_rows > 0) {
        echo "<table id='booksTable' class='books-table'>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Book Name</th>
                        <th>Borrower Name</th>
                        <th>Borrow Date</th>
                        <th>Return Date</th>
                    </tr>
                </thead>
                <tbody>";

        // Output data for each row
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["id"] . "</td>
                    <td>" . htmlspecialchars($row["book_name"]) . "</td>
                    <td>" . htmlspecialchars($row["borrower_name"]) . "</td>
                    <td>" . htmlspecialchars($row["borrow_date"]) . "</td>
                    <td>" . htmlspecialchars($row["return_date"]) . "</td>
                  </tr>";
        }
        echo "</tbody></table>";
    } else {
        echo "<p class='no-records'>No records found.</p>";
    }

    // Close the database connection
    $conn->close();
    ?>
</div>

<!-- JavaScript for Date Filtering -->
<script>
    document.getElementById('filterBtn').addEventListener('click', () => {
        const table = document.getElementById('booksTable');
        const filterType = document.getElementById('dateFilter').value;
        const startDate = new Date(document.getElementById('startDate').value);
        const endDate = new Date(document.getElementById('endDate').value);
        const rows = Array.from(table.querySelectorAll('tbody tr'));

        rows.forEach(row => {
            const dateCell = filterType === 'borrow_date' ? row.children[3].textContent : row.children[4].textContent;
            const rowDate = new Date(dateCell.trim());

            // Check if the row date falls within the selected range
            if (rowDate >= startDate && rowDate <= endDate) {
                row.style.display = ''; // Show the row
            } else {
                row.style.display = 'none'; // Hide the row
            }
        });
    });
</script>

<script src="assets/js/main.js"></script>
</body>
</html>