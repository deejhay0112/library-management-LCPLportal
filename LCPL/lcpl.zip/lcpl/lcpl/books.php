<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: admin-login.php");
    exit();
}

// Prevent caching for this page
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Expires: 0");
header("Pragma: no-cache");
?>




<?php
include 'db.php'; // Ensure db.php has the correct database connection setup
$currentPage = 'library_management';
// Initialize a variable to store the number of books
$next_no_of_books = 1;

// Fetch the highest number of books from the database
$sql = "SELECT MAX(`No of Books`) as max_no FROM book"; 
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $next_no_of_books = $row['max_no'] + 1; // Increment the highest number by one
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $no_of_books = $conn->real_escape_string($_POST['no_of_books']);
    $author = $conn->real_escape_string($_POST['author']);
    $author_title = $conn->real_escape_string($_POST['author_title']);
    $accession_no = $conn->real_escape_string($_POST['accession_no']);
    $call_no = $conn->real_escape_string($_POST['call_no']);
    $quantity = $conn->real_escape_string($_POST['quantity']);
    $unit = $conn->real_escape_string($_POST['unit']);
    $date_acquired = $conn->real_escape_string($_POST['date_acquired']);
    
    // Insert query
    $sql = "INSERT INTO book (`No of Books`, Author_Title, `Title`, `Accession No`, `Call No`, Quantity, Unit, `Date Acquired`)
    VALUES ('$no_of_books', '$author', '$author_title', '$accession_no', '$call_no', '$quantity', '$unit', '$date_acquired')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('New book added successfully');</script>";
        echo "<script>window.location.href='books.php';</script>"; // Redirect after insert
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/books.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined&display=swap" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body id="body-pd">
    <header class="header" id="header">
        <div class="header__toggle">
            <i class='bx bx-menu' id="header-toggle"></i>
        </div>
    </header>
    <div class="l-navbar" id="nav-bar">
        <nav class="nav">
            <div>
                <a href="#" class="nav__logo">
                    <img src="logo/vls_logo.jpg" alt="Library Logo" class="nav__logo-img">
                    <span class="nav__logo-name">LIPA CITY PUBLIC LIBRARY</span>
                </a>
                <div class="nav__list">
                    <a href="books.php" class="nav__link <?php echo ($currentPage == 'library_management') ? 'active' : ''; ?>">
                        <i class='bx bx-grid-alt nav__icon'></i>
                        <span class="nav__name">Library Management</span>
                    </a>

                    <a href="logbookAdmin.php" class="nav__link <?php echo ($currentPage == 'logbook') ? 'active' : ''; ?>">
                        <i class='bx bx-message-square-detail nav__icon'></i>
                        <span class="nav__name">Logbook</span>
                    </a>

                    <a href="dashboard.php" class="nav__link <?php echo ($currentPage == 'dashboard') ? 'active' : ''; ?>">
                        <i class='bx bx-bar-chart-alt-2 nav__icon'></i>
                        <span class="nav__name">Analytics</span>
                    </a>

                    <a href="transaction_book.php" class="nav__link <?php echo ($currentPage == 'transaction_books') ? 'active' : ''; ?>">
                        <i class='bx bx-book nav__icon'></i>
                        <span class="nav__name">Transaction Books</span>
                    </a>
                    <a href="admin_account.php" class="nav__link <?php echo ($currentPage == 'admin_account') ? 'active' : ''; ?>">
                    <i class='bx bx-user nav__icon'></i>
                        <span class="nav__name">Admin</span>
                    </a>
                </div>
            </div>

            <a href="logout.php" class="nav__link">
                <i class='bx bx-log-out nav__icon'></i>
                <span class="nav__name">Log Out</span>
            </a>
        </nav>
    </div>
</head>
<body>
    <div class="container">
        <div class="box-container">
            <!-- Filter input and buttons -->
            <div class="filter-container">
            <input type="text" id="searchInput" class="searchInput" placeholder="Search...">
    <button type="button" class="search-icon-button" onclick="searchBooks()">
        <i class="fas fa-search"></i> <!-- Search Icon -->
    </button>
    </button>
    <button class="button Add-Book-Button" id="openModalBtn">
        <i class="fas fa-plus"></i> <!-- Add Book Icon -->
    </button>
    <button class="button Add-Book-Button" onclick="refreshPage()">
        <i class="fas fa-sync-alt"></i> <!-- Refresh Icon -->
    </button>
</div>

            <!-- Scroll buttons aligned to the right -->
            <div class="scroll-container">
                <div class="scroll-up-container">
                    <button class="scroll-button" onclick="scrollToTop()">
                        <i class="fas fa-chevron-up"></i>
                    </button>
                </div>
                <div class="scroll-down-container">
                    <button class="scroll-button" onclick="scrollToBottom()">
                        <i class="fas fa-chevron-down"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</body>



    </div>
</div>
        </div>
    <div class="table-wrapper">
        
        <table id="booksTable">
            <thead>
                <tr>
                    <th>Book No.</th>
                    <th>Author</th>
                    <th>Title</th>
                    <th>Accession No</th>
                    <th>Call No</th>
                    <th>Quantity</th>
                    <th>Unit</th>
                    <th>Date Acquired</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id='booksTablebody'>
            <?php include 'fetch_books.php'; ?>
            
                                </tbody>
                            </table>
                        </div>
                    </div>
</div>

    <!-- Modal -->
    <div id="bookModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <span class="close">&times;</span>
                <h2>Add New Book</h2>
            </div>
            <div class="modal-body">
            <form method="post" action="add-book.php">
    <div class="form-group">
        <label for="no_of_books">No. of Books</label>
        <input type="number" id="no_of_books" name="no_of_books" value="<?php echo htmlspecialchars($next_no_of_books); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="author">Author</label>
        <input type="text" id="author" name="author" required>
    </div>
    <div class="form-group">
        <label for="author_title">Book Title</label>
        <input type="text" id="author_title" name="author_title" required>
    </div>
    <div class="form-group">
        <label for="accession_no">Accession No</label>
        <input type="text" id="accession_no" name="accession_no" required>
    </div>
    <div class="form-group">
        <label for="call_no">Call No</label>
        <input type="text" id="call_no" name="call_no" required>
    </div>
    <div class="form-group">
        <label for="quantity">Quantity</label>
        <input type="number" id="quantity" name="quantity" required>
    </div>
    <div class="form-group">
        <label for="unit">Unit</label>
        <input type="text" id="unit" name="unit" required>
    </div>
    <div class="form-group">
        <label for="date_acquired">Date Acquired</label>
        <input type="date" id="date_acquired" name="date_acquired" required>
    </div>
    <div class="form-group">
        <input type="submit"class="button Add-Book-Button" value="Add Book">
        <input type="button"class="button Add-Book-Button" value="Cancel" id="closeModalBtn">
    </div>
</form>

            </div>
        </div>
    </div>

    <!-- Edit Modal -->
<!-- Edit Modal -->
<div id="editBookModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <span class="close" id="closeEditModal">&times;</span>
            <h2>Edit Book</h2>
        </div>
        <div class="modal-body">
            <form id="editBookForm" method="post" action="edit_book.php">
            <input type="hidden" name="book_id" id="edit_book_id" value="">

                <div class="form-group">
                    <label for="edit_no_of_books">No. of Books</label>
                    <input type="number" id="edit_no_of_books" name="no_of_books" readonly>
                </div>
                <div class="form-group">
                    <label for="edit_author">Author</label>
                    <input type="text" id="edit_author" name="author" required>
                </div>
                <div class="form-group">
                    <label for="edit_author_title">Book Title</label>
                    <input type="text" id="edit_author_title" name="author_title" required>
                </div>
                <div class="form-group">
                    <label for="edit_accession_no">Accession No</label>
                    <input type="text" id="edit_accession_no" name="accession_no" required>
                </div>
                <div class="form-group">
                    <label for="edit_call_no">Call No</label>
                    <input type="text" id="edit_call_no" name="call_no" required>
                </div>
                <div class="form-group">
                    <label for="edit_quantity">Quantity</label>
                    <input type="number" id="edit_quantity" name="quantity" required>
                </div>
                <div class="form-group">
                    <label for="edit_unit">Unit</label>
                    <input type="text" id="edit_unit" name="unit" required>
                </div>
                <div class="form-group">
                    <label for="edit_date_acquired">Date Acquired</label>
                    <input type="date" id="edit_date_acquired" name="date_acquired" required>
                </div>
                <div class="form-group">
                    <input type="submit"class="button Add-Book-Button" value="Update Book">
                    <input type="button"class="button Add-Book-Button" value="Cancel" id="closeEditModalBtn">
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function scrollToTop() {
    const tableWrapper = document.querySelector('.table-wrapper');
    tableWrapper.scrollTo({ top: 0, behavior: 'instant' });
}

function scrollToBottom() {
    const tableWrapper = document.querySelector('.table-wrapper');
    tableWrapper.scrollTo({ top: tableWrapper.scrollHeight, behavior: 'instant' });
}


</script>


<script src="assets/js/book.js"></script>
<script src="assets/js/sweet_alert.js"></script>
<script src="assets/js/main.js"></script>
</body>
<script>
    // Prevent back navigation after logout
    window.history.pushState(null, "", window.location.href);
    window.onpopstate = function () {
        window.history.pushState(null, "", window.location.href);
        // Optional: Redirect to login if user tries to go back
        window.location.href = "admin-login.php";
    };
</script>

</html>
