<?php
include 'db.php';

function fetchLogbook() {
    global $conn;

    // Default to today's date if no date is provided
    $date = isset($_GET['date']) ? $_GET['date'] : date("Y-m-d");

    // Prepare SQL query to fetch entries for the specified date
    $sql = "SELECT `ID No.`, `School`, `Date`, `Age`, `Sex`, `time`, `Elementry`, `Shs`, `Highschool`, `College`, `PostGrad`, `Osy`
            FROM male_1 
            WHERE `Date` = '$date'
            ORDER BY `ID No.` ASC";

    if ($result = $conn->query($sql)) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['ID No.']) . "</td>";
            echo "<td>" . htmlspecialchars($row['School']) . "</td>";
            echo "<td>" . htmlspecialchars($row['Date']) . "</td>";
            echo "<td>" . htmlspecialchars($row['Age']) . "</td>";
            echo "<td>" . htmlspecialchars($row['Sex']) . "</td>";
            echo "<td>" . htmlspecialchars($row['time']) . "</td>";
            echo "<td>" . ($row['Elementry'] == 'Yes' ? 'Yes' : 'No') . "</td>";
            echo "<td>" . ($row['Highschool'] == 'Yes' ? 'Yes' : 'No') . "</td>";
            echo "<td>" . ($row['Shs'] == 'Yes' ? 'Yes' : 'No') . "</td>";
            echo "<td>" . ($row['College'] == 'Yes' ? 'Yes' : 'No') . "</td>";
            echo "<td>" . ($row['PostGrad'] == 'Yes' ? 'Yes' : 'No') . "</td>";
            echo "<td>" . ($row['Osy'] == 'Yes' ? 'Yes' : 'No') . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='12'>No logbook entries found for this date.</td></tr>";
    }

    $conn->close();
}
?>
