<?php
header('Content-Type: application/json');

// Include your database connection file
include 'db.php'; // Make sure the path is correct

// Check connection
if ($conn->connect_error) {
    die(json_encode(['error' => 'Connection failed: ' . $conn->connect_error]));
}

// Get the date from the request
$date = isset($_GET['date']) ? $_GET['date'] : '';

// Log the received date for debugging
error_log("Date received: " . $date);

// Query to count users by gender for the selected date
$sql = "SELECT 
            SUM(CASE WHEN Sex = 'MALE' THEN 1 ELSE 0 END) AS male,
            SUM(CASE WHEN Sex = 'FEMALE' THEN 1 ELSE 0 END) AS female,
            SUM(CASE WHEN Sex = 'LGBTQ' THEN 1 ELSE 0 END) AS lgbt 
        FROM male_1 
        WHERE Date = '$date'"; // Ensure 'Date' is the correct column name

$result = $conn->query($sql);

// Check for query success and fetch data
if ($result) {
    $data = $result->fetch_assoc(); // Fetch data as an associative array
    echo json_encode($data); // Return the data as JSON
} else {
    echo json_encode(['error' => 'Query error: ' . $conn->error]);
}

// Close the database connection
$conn->close();
?>
