<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: admin-login.php");
    exit();
}

// Prevent caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Expires: 0");
header("Pragma: no-cache");
$currentPage = 'admin_account';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/books.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
    /* Main layout container */
    .admin-accounts-container {
        display: flex;
        gap: 20px;
        padding: 20px;
        justify-content: space-around;
        align-items: flex-start;
        background-color: #1a1a2e;
        min-height: 100vh;
        color: #fff;
    }
    
    /* Form container styling */
    .form-container {
        width: 30%;
        padding: 20px;
        border-radius: 8px;
        background-color: #f9f9f9;
        color: #333;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    .form-container h2 {
        font-size: 1.6em;
        color: #333;
    }

    .form-container label {
        font-weight: bold;
        margin-bottom: 5px;
    }

    .form-container input[type="text"],
    .form-container input[type="email"],
    .form-container input[type="password"] {
        width: 100%;
        padding: 12px;
        margin-bottom: 10px;
        border: 1px solid #ddd;
        border-radius: 5px;
        font-size: 1em;
    }

    .form-container button {
        padding: 12px;
        background-color: #007bff;
        border: none;
        border-radius: 5px;
        color: #fff;
        font-size: 1em;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .form-container button:hover {
        background-color: #0056b3;
    }

    /* Table container styling */
    .table-container {
        width: 65%;
        max-height: 600px;
        overflow-y: auto;
        padding: 20px;
        border-radius: 8px;
        background-color: #f9f9f9;
        color: #333;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    }

    .table-container table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.95em;
        table-layout: auto;
    }

    .table-container th, .table-container td {
        padding: 8px 10px;
        border-bottom: 1px solid #ddd;
        text-align: center;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .table-container th {
        background-color: #007bff;
        color: #fff;
        font-weight: bold;
    }

    .table-container td {
        max-width: 180px; /* Allow email to take more space */
    }

    .table-container .action-buttons {
        display: flex;
        justify-content: center;
        gap: 8px;
    }

    /* Action buttons as links */
    .table-container .action-buttons a {
        color: #fff;
        text-decoration: none;
        padding: 6px 10px;
        border-radius: 5px;
        font-size: 0.85em;
        font-weight: bold;
    }

    .table-container .edit-button {
        background-color: #28a745;
    }

    .table-container .delete-button {
        background-color: #dc3545;
    }

    .table-container .action-buttons a:hover {
        opacity: 0.8;
    }

    /* Modal styling */
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        justify-content: center;
        align-items: center;
    }

    /* Enhanced styling for modal content */
.modal-content {
    background-color: #fff;
    padding: 30px 40px;
    border-radius: 12px;
    width: 400px;
    max-width: 90%;
    color: #333;
    box-shadow: 0px 6px 20px rgba(0, 0, 0, 0.2);
    font-family: Arial, sans-serif;
}

.modal-content h2 {
    margin-bottom: 20px;
    font-size: 1.8em;
    color: #333;
    text-align: center;
    font-weight: bold;
}

.modal-content label {
    font-weight: bold;
    margin-bottom: 5px;
    display: block;
    color: #555;
}

.modal-content input[type="text"],
.modal-content input[type="email"],
.modal-content input[type="password"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 8px;
    font-size: 1em;
    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
    transition: border-color 0.3s;
}

.modal-content input[type="text"]:focus,
.modal-content input[type="email"]:focus,
.modal-content input[type="password"]:focus {
    border-color: #007bff;
    outline: none;
}

.button {
    display: inline-block;
    padding: 12px 24px;
    font-size: 16px;
    font-weight: 500;
    color: #ffffff;
    background-color: #007bff; /* Default blue */
    border: none;
    border-radius: 6px;
    text-align: center;
    text-decoration: none;
    transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease, transform 0.2s ease, box-shadow 0.3s ease;
    cursor: pointer;
    margin: 10px 0;
}

.button:hover {
    background-color: #ffffff; /* Change to white */
    color: #007bff; /* Original blue color for text */
    border: 2px solid #007bff; /* Blue border */
    transform: translateY(-2px); /* Slight lift effect */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15); /* Subtle shadow */
}

.button.Add-Book-Button {
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 12px 24px;
    font-size: 16px;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    margin-left: auto;
}

.button.Add-Book-Button:hover {
    background-color: #ffffff;
    color: #007bff;
    border: 2px solid #007bff;
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

.button.edit-button {
    background-color: #28a745; /* Green */
}

.button.edit-button:hover {
    background-color: #ffffff;
    color: #28a745; /* Green text on hover */
    border: 2px solid #28a745;
}

.button:focus {
    outline: none;
    box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.5);
}




</style>
</head>
<body id="body-pd">
    <header class="header" id="header">
        <div class="header__toggle">
            <i class='bx bx-menu' id="header-toggle"></i>
        </div>
    </header>

    <div class="l-navbar" id="nav-bar">
        <nav class="nav">
            <div>
                <a href="#" class="nav__logo">
                    <img src="logo/vls_logo.jpg" alt="Library Logo" class="nav__logo-img">
                    <span class="nav__logo-name">LIPA CITY PUBLIC LIBRARY</span>
                </a>
                <div class="nav__list">
                    <a href="books.php" class="nav__link <?php echo ($currentPage == 'library_management') ? 'active' : ''; ?>">
                        <i class='bx bx-grid-alt nav__icon'></i>
                        <span class="nav__name">Library Management</span>
                    </a>

                    <a href="logbookAdmin.php" class="nav__link <?php echo ($currentPage == 'logbook') ? 'active' : ''; ?>">
                        <i class='bx bx-message-square-detail nav__icon'></i>
                        <span class="nav__name">Logbook</span>
                    </a>

                    <a href="dashboard.php" class="nav__link <?php echo ($currentPage == 'dashboard') ? 'active' : ''; ?>">
                        <i class='bx bx-bar-chart-alt-2 nav__icon'></i>
                        <span class="nav__name">Analytics</span>
                    </a>

                    <a href="transaction_book.php" class="nav__link <?php echo ($currentPage == 'transaction_books') ? 'active' : ''; ?>">
                        <i class='bx bx-book nav__icon'></i>
                        <span class="nav__name">Transaction Books</span>
                    </a>
                    <a href="admin_account.php" class="nav__link <?php echo ($currentPage == 'admin_account') ? 'active' : ''; ?>">
                    <i class='bx bx-user nav__icon'></i>
                        <span class="nav__name">Admin</span>
                    </a>
                </div>
            </div>
            <a href="logout.php" class="nav__link">
                <i class='bx bx-log-out nav__icon'></i>
                <span class="nav__name">Log Out</span>
            </a>
        </nav>
    </div>

    <div class="admin-accounts-container">
        <!-- Left Form Section -->
        <div class="form-container">
    <h2>Create New Account</h2>
    <form id="accountForm" action="add_account.php" method="POST">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" required>
        
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required>
        
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required>

        <button type="submit" class="button Add-Book-Button">Create Account</button>
    </form>
</div>

        <!-- Right Table Section -->
        <div class="table-container">
            <div class="table-wrapper">
                <table id="accountsTable" class="display">
                    <thead>
                        <tr>
                            <th>ID No</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Password</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php include 'fetch_accounts.php'; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Edit Account Modal -->
    <!-- Edit Account Modal -->
<div id="editAccountModal" class="modal">
    <div class="modal-content">
        <h2>Edit Account</h2>
        <form id="editAccountForm" action="edit_account.php" method="POST">
            <input type="hidden" id="edit_id" name="id">
            
            <label for="edit_username">Username</label>
            <input type="text" id="edit_username" name="username" required>

            <label for="edit_email">Email</label>
            <input type="email" id="edit_email" name="email" required>

            <label for="edit_password">New Password (leave blank to keep current)</label>
            <input type="password" id="edit_password" name="password">

            <div class="button-group">
                <button type="submit" class="button edit-button">Update Account</button>
                <button type="button" class="button cancel-button" onclick="closeModal('editAccountModal')">Cancel</button>
            </div>
        </form>
    </div>
</div>
   <!-- Delete Confirmation Modal -->
<div id="deleteAccountModal" class="modal">
    <div class="modal-content">
        <h2>Confirm Delete</h2>
        <p>Are you sure you want to delete this account?</p>
        <form id="deleteAccountForm" action="delete_account.php" method="POST">
            <input type="hidden" id="delete_id" name="id">
            <div class="button-group">
                <button type="submit" class="button delete-button">Yes, Delete</button>
                <button type="button" class="button cancel-button" onclick="closeModal('deleteAccountModal')">Cancel</button>
            </div>
        </form>
    </div>
</div>
    <script>
        // Open the Edit Account Modal
        function openEditModal(id, username, email) {
            document.getElementById('edit_id').value = id;
            document.getElementById('edit_username').value = username;
            document.getElementById('edit_email').value = email;
            document.getElementById('edit_password').value = ""; // Clear password field
            document.getElementById('editAccountModal').style.display = 'flex';
        }

        // Open the Delete Account Confirmation Modal
        function openDeleteModal(id) {
            document.getElementById('delete_id').value = id;
            document.getElementById('deleteAccountModal').style.display = 'flex';
        }

        // Close any modal
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        // Close modal if clicked outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        };

        // SweetAlert for success notifications on account creation and update
        document.addEventListener("DOMContentLoaded", function() {
            const urlParams = new URLSearchParams(window.location.search);
            const status = urlParams.get("status");

            if (status === "added") {
                Swal.fire({
                    icon: 'success',
                    title: 'Account Created',
                    text: 'The account has been created successfully!',
                    confirmButtonColor: '#007bff'
                });
            } else if (status === "updated") {
                Swal.fire({
                    icon: 'success',
                    title: 'Account Updated',
                    text: 'The account has been updated successfully!',
                    confirmButtonColor: '#007bff'
                });
            }else if (status === "deleted") {
            Swal.fire({
                icon: 'success',
                title: 'Account Deleted',
                text: 'The account has been deleted successfully!',
                confirmButtonColor: '#007bff'
            });
           } else if (status === "error") {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'There was a problem deleting the account.',
                    confirmButtonColor: '#d33'
                });
            }
        });
    </script>
    <script src="assets/js/main.js"></script>
</body>
</html>
