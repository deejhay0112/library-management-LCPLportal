<?php
include 'db.php';

$date = isset($_GET['date']) ? $_GET['date'] : date("Y-m-d");

// Prepare SQL query to fetch entries for the specified date
$sql = "SELECT `ID No.`, `School`, `Date`, `Age`, `Sex`, `time`, `Elementry`, `Shs`, `Highschool`, `College`, `PostGrad`, `Osy`
        FROM male_1 
        WHERE `Date` = '$date'
        ORDER BY `ID No.` ASC";

$data = [];
if ($result = $conn->query($sql)) {
    while ($row = $result->fetch_assoc()) {
        $data[] = [
            "ID_No" => $row['ID No.'],
            "School" => $row['School'],
            "Date" => $row['Date'],
            "Age" => $row['Age'],
            "Sex" => $row['Sex'],
            "Time" => $row['time'],
            "Elementary" => $row['Elementry'] === 'Yes' ? 'Yes' : 'No',
            "Highschool" => $row['Highschool'] === 'Yes' ? 'Yes' : 'No',
            "Shs" => $row['Shs'] === 'Yes' ? 'Yes' : 'No',
            "College" => $row['College'] === 'Yes' ? 'Yes' : 'No',
            "PostGrad" => $row['PostGrad'] === 'Yes' ? 'Yes' : 'No',
            "Osy" => $row['Osy'] === 'Yes' ? 'Yes' : 'No'
        ];
    }
} 

// Output JSON
header('Content-Type: application/json');
echo json_encode($data);

$conn->close();
?>
